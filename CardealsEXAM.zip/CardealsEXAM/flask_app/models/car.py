from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash, session
from flask_app.models import user
from datetime import datetime


class Car:
    DB = "user"

    def __init__(self, cars):
        self.id = cars["id"]
        self.price = cars["price"]
        self.model = cars["model"]
        self.make = cars["make"]
        self.year = cars["year"]
        self.description = cars["description"]
        self.created_at = cars["created_at"]
        self.updated_at = cars["updated_at"]
        self.user = None

    @classmethod
    def check_permissions(cls, car_id):  # done
        data = {"id": car_id}
        query = """SELECT users_id FROM cars WHERE id = %(id)s"""
        response = connectToMySQL(cls.DB).query_db(query, data)[0]
        if int(response["users_id"]) == int(session['user_id']):
            return True
        return False

    @classmethod
    def get_one_by_id(cls, car_id):  # done
        query = """ SELECT cars.*, users.*
                    FROM cars
                    JOIN users ON cars.users_id = users.id WHERE cars.id = %(id)s;"""
        data = {"id": car_id}
        car_dict = connectToMySQL(cls.DB).query_db(query, data)[0]
        car_obj = cls(car_dict)
        user_obj = user.User(
            {
                "id": car_dict["users.id"],
                "first_name": car_dict["first_name"],
                "last_name": car_dict["last_name"],
                "email": car_dict["email"],
                "password": car_dict["password"],
                "created_at": car_dict["users.created_at"],
                "updated_at": car_dict["users.updated_at"],
            }
        )
        car_obj.user = user_obj
        return car_obj

    @classmethod
    def get_all(cls):
        query = """SELECT cars.*, users.*
                    FROM cars
                    JOIN users ON cars.users_id = users.id
                    """
        results = connectToMySQL(cls.DB).query_db(query)
        cars = []

        for car_dict in results:
            car_obj = cls(car_dict)
            user_obj = user.User(
                {
                    "id": car_dict["users.id"],
                    "first_name": car_dict["first_name"],
                    "last_name": car_dict["last_name"],
                    "email": car_dict["email"],
                    "password": car_dict["password"],
                    "created_at": car_dict["users.created_at"],
                    "updated_at": car_dict["users.updated_at"],
                }
            )

            car_obj.user = user_obj
            cars.append(car_obj)
        return cars

    @classmethod
    def delete_by_id(cls, car_id):
        query = """DELETE FROM cars WHERE id =%(id)s"""
        data = {"id": car_id}
        connectToMySQL(cls.DB).query_db(query, data)
        return

    @classmethod
    def save(cls, car_data):
        car_data = {**car_data}
        created = datetime.now()
        car_data['created_at'] = created
        car_data['updated_at'] = created
        car_data['users_id'] = session['user_id']
        query = """INSERT INTO cars(price, model, make, year, description, created_at, updated_at, users_id ) 
        VALUES (%(price)s, %(model)s, %(make)s, %(year)s, %(description)s, %(created_at)s, %(updated_at)s, %(users_id)s);"""

        connectToMySQL(cls.DB).query_db(query, car_data)

    @classmethod
    def update_car(cls, car_data):
        updated_at = datetime.now()
        car_data['updated_at'] = updated_at
        query = """UPDATE cars SET 
                    price = %(price)s, 
                    model = %(model)s, 
                    make = %(make)s, 
                    year = %(year)s, 
                    description = %(description)s,
                    updated_at = %(updated_at)s
                    WHERE id = %(id)s"""
        connectToMySQL(cls.DB).query_db(query, car_data)
        return True


    @classmethod
    def is_valid(cls, car_dict):
        valid = True

        if int(car_dict.get("price")) <= 0:
            valid = False
            flash("price can't be 0 or less", "cars-price")
        if len(car_dict.get("model")) == 0:
            valid = False
            flash("model can't be blank", "cars-model")
        elif len(car_dict.get("make")) == 0:
            valid = False
            flash("make can't be blank", "cars-make")
        if len(car_dict.get("description")) == 0:
            valid = False
            flash("description can't be blank", "cars-description")
        if int(car_dict.get("year")) <= 0:
            valid = False
            flash("year can't be 0 or less", "cars-year")
        elif int(car_dict.get("year")) <= 1885:
            valid = False
            flash("cars didnt exist back then ", "cars-year")
        elif int(car_dict.get("year")) >= datetime.now().year:
            valid = False
            flash("Doc Brown is that you?", "cars-year")
        return valid