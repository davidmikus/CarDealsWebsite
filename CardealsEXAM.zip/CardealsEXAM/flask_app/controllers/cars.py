from flask_app import app
from flask_app.models.user import User
from flask import render_template, redirect, session, request, flash
from flask_app.models.car import Car


@app.route("/dashboard")
def cars_home():
    if "user_id" not in session:
        flash("you must be loged in ")
        return redirect("/")
    user = User.get_by_id(session["user_id"])
    cars = Car.get_all()
    for car in cars:
        print(car.model)
    return render_template("board.html", user=user, cars=cars)


@app.route('/new', methods=['GET'])
def get_create_car():
    return render_template('create_car.html')


@app.route('/new', methods=['POST'])
def post_create_car():
    is_valid = Car.is_valid(request.form)
    if is_valid:
        Car.save(request.form)
        return redirect('/dashboard')
    return redirect('/new')


@app.route('/edit/<int:car_id>', methods=['GET'])
def get_edit_car(car_id):
    if Car.check_permissions(car_id):
        car = Car.get_one_by_id(car_id)
        return render_template('edit_car.html', car=car)
    return redirect("/dashboard")


@app.route('/edit/<int:car_id>', methods=['POST'])
def post_edit_car(car_id):
    if Car.check_permissions(car_id):
        is_valid = Car.is_valid(request.form)
        req = {**request.form, "id": car_id}
        if is_valid:
            Car.update_car(req)
            return redirect('/dashboard')
        return redirect(f"/edit/{car_id}")
    return redirect("/dashboard")


@app.route('/show/<int:car_id>', methods=['GET'])
def car_details(car_id):
    try:
        car = Car.get_one_by_id(car_id)
        if car.user.id != session.get("user_id"):
            return render_template('car_detail.html', car=car)
        return redirect("/dashboard")
    except IndexError:
        return redirect('/dashboard')



@app.route('/show/purchase/<int:car_id>')
def delete_car(car_id):
    Car.delete_by_id(car_id)
    return redirect('/dashboard')